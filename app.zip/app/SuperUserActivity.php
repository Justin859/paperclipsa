<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SuperUserActivity extends Model
{
    //
}
