<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RefereeActivity extends Model
{
    //
}
