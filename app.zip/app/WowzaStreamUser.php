<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WowzaStreamUser extends Model
{
    //
}
