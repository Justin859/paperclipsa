@extends('layouts.app')

<div class="container">
    <div class="row">
        <div class="col">
        
            <div>Cancled Payment</div>
        
        </div>
    </div>
</div>