@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="jumbotron banner">
                
            </div>
        </div>
    </div>
</div>


@endsection

